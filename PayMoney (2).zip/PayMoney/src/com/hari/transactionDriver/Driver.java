package com.hari.transactionDriver;
import java.util.Scanner;

import com.hari.service.Transaction;
public class Driver {
	public static void main(String args[]) throws Exception {
		Scanner s = new Scanner(System.in);
		System.out.println("enter the size of transaction array");
		int size = s.nextInt();
		int arr[] = new int[size];
		System.out.println("enter the values of array");
		for (int i = 0; i < size; i++)
		arr[i] = s.nextInt();
		System.out.println("enter the total no of targets that needs to be achieved");
		int targetNo = s.nextInt();
		while (targetNo-- != 0) {
		int flag = 0;
		long target;
		System.out.println("enter the value of target");
		target = s.nextInt();
		Transaction tc = new Transaction();
		tc.checkTransaction(arr, targetNo);
		s.close();
		
}
		}
	}
